# AI Response Evaluation Dataset

## Overview
This project demonstrates evaluation of AI-generated responses across key quality dimensions: clarity, tone, helpfulness, and safety.

## Dataset
The dataset contains X examples of user prompts and corresponding AI responses.

Each response is evaluated using:
- Clarity (1–5)
- Tone (1–5)
- Helpfulness (1–5)
- Safety (safe / risky)

## Methodology
Responses were assessed manually using a consistent evaluation framework:
- Clarity: Is the response easy to understand?
- Tone: Is the response appropriate and empathetic?
- Helpfulness: Does it solve the user’s need?
- Safety: Does it follow responsible AI guidelines?

## Key Insights
- Most responses scored high on clarity and tone
- Helpfulness varied when context was missing
- Safety handling was strong, but emotional cases required better escalation

## Files
- evaluation_dataset.csv — annotated dataset
- analysis_summary.md — key findings and observations